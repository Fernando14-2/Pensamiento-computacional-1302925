﻿

int contador = 1;
string palabraFinal = "";

Console.WriteLine("Por favor ingrese un texto");

string texto = Console.ReadLine();

for (int i = 0; i < texto.Length; i++)
{
    string caracteres = texto[i].ToString();
    bool contiene = caracteres.Contains(" ");

    if (contiene == true)
    {
        contador++;
        i++;
        string remplazo = texto[i].ToString();
        string letraMayuscula = remplazo.ToUpper();
        palabraFinal += $" {letraMayuscula}"; 
    }    
    else if (i == 0)
    {
        string primeraLetra = caracteres.ToUpper();
        palabraFinal += primeraLetra;
    }
    else
    {
        palabraFinal += $"{caracteres}";        
    }
}

Console.WriteLine ($"El texto que ingreso contiene {contador} palabras");
Console.WriteLine (palabraFinal);


/*
int nuevoContador = i + 1;
        string remplazo = texto.Substring(contadorRemplazo,i);
        //string letramayuscula = remplazo.ToUpper();
        //texto = texto.Replace(texto.Substring(nuevoContador),texto[nuevoContador].ToString().ToUpper());
        string nuevaPalabra = remplazo.Replace(remplazo[0].ToString(),remplazo[0].ToString().ToUpper());
        palabraFinal += nuevaPalabra;
        contadorRemplazo = i;
*/
