﻿
try
{
    Random generador = new Random();
    int numeroAleatorio = generador.Next(0,51);   

    Console.WriteLine("Adivine el número de 0 a 50, ingrese su intento a continuación:");
    int usuarioIntento = Convert.ToInt32(Console.ReadLine());

    while (usuarioIntento != numeroAleatorio)
    {
        if (usuarioIntento > numeroAleatorio)
        {
            Console.WriteLine("EL número ingresado es mayor, intenta nuevamente con uno más pequeño");
            usuarioIntento = Convert.ToInt32(Console.ReadLine());
        }
        else //if (usuarioIntento < numeroAleatorio)
        {
            Console.WriteLine("El número ingresado es menor, intenta nuevamente con uno más grande");
            usuarioIntento = Convert.ToInt32(Console.ReadLine());
        }
    } 
    Console.WriteLine("¡Felicidades, Adivinaste el número! el número es: " + usuarioIntento);
}
catch (System.Exception)
{
    Console.WriteLine("Lo ingresado no es un número");
}

/*
Random generador = new Random();
int numeroAleatorio = generador.Next(0,51);   

Console.WriteLine("Adivine el número de 0 a 50, ingrese su intento a continuación:");
int usuarioIntento = Convert.ToInt32(Console.ReadLine());

while (usuarioIntento != numeroAleatorio)
{
    if (usuarioIntento > numeroAleatorio)
    {
        Console.WriteLine("EL número ingresado es mayor, intenta nuevamente con uno más pequeño");
        usuarioIntento = Convert.ToInt32(Console.ReadLine());
    }
    else if (usuarioIntento < numeroAleatorio)
    {
        Console.WriteLine("El número ingresado es menor, intenta nuevamente con uno más grande");
        usuarioIntento = Convert.ToInt32(Console.ReadLine());
    }
    else
    {
        Console.WriteLine("Lo que ingresaste no es un número, intenta de nuevo con un núnero");
        usuarioIntento = Convert.ToInt32(Console.ReadLine());
    }
} 
Console.WriteLine("¡Felicidades, Adivinaste el número! el número es: " + usuarioIntento);
*/









/*Console.WriteLine("Ingrse un número para la sucesión de Fibonacci");

try 
{
    int numero = Convert.ToInt32(Console.ReadLine());

    if (numero <= 0)
    {
        Console.WriteLine("El número debe ser mayor a 0");
    }
    else
    {

    string fibonacci = "";
    int nuevoValor, valor1 = 0, valor2 = 1, contador = 1;

        while (contador <= numero)
        {
            if (contador == 1)
            {
                fibonacci = "0";
            }
            else if (contador == 2)
            {
                fibonacci = "0,1";
            }
            else
            {
                nuevoValor = valor1 + valor2;
                fibonacci = fibonacci + "," + nuevoValor;
                valor1 = valor2;
                valor2 = nuevoValor;
            }
            contador++;
        }
        Console.WriteLine("La sucesión de Fibonacci para el número ingresado es: " + fibonacci);

    }

}
catch (System.Exception)
{
    Console.WriteLine("Ingrese un número valido");
}
*/