﻿// See https://aka.ms/new-console-template for more information
using System.Security.Cryptography.X509Certificates;

Console.WriteLine("Laboratorio 8");
Console.WriteLine("Por favor Ingrese su nombre completo");
string nombreCompleto; 
nombreCompleto = Console.ReadLine();
Console.WriteLine("Por favor ingrese su altura en metros");
decimal altura;
altura = Convert.ToDecimal(Console.ReadLine());
Console.WriteLine("Por favor ingrese su edad");
int edadDada; 
edadDada = Convert.ToInt16(Console.ReadLine());
Console.WriteLine("Por favor ingrese la inicial de su mascota");
char inicialMascota; 
inicialMascota = Convert.ToChar(Console.ReadLine());
Console.WriteLine("Hola " + nombreCompleto + " de altura " + altura + " de edad " + edadDada +  " años, La inicial de su mascota es: " + inicialMascota);