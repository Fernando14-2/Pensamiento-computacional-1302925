﻿/* primer ejemplo
int numero;

do
{
    Console.WriteLine("Ingrese un número positivo");
    numero = Convert.ToInt32(Console.ReadLine());

    if (numero <= 0)
    {
        Console.WriteLine("Número incorrecto, ingrese de nuevo");
    }
    else
    {
        Console.WriteLine("Numero correcto.");
    }

} while (numero <= 0);
*/

/* segundo ejemplo
Console.WriteLine("Suma de los números de 1 a 100");

int suma = 0;

for (int actual = 0; actual < 101; actual++)
{
    suma += actual;
}

Console.WriteLine("La suma es: "+ suma);
*/

/* Primer ejercicio
int edadUsuario;

do
{
    Console.WriteLine("Por favor ingrese su edad");
    edadUsuario = Convert.ToInt32(Console.ReadLine());

    if ((edadUsuario >= 1) && (edadUsuario <= 100))
    {
        Console.WriteLine("La edad ingresada fue: "+ edadUsuario);
    }
    else
    {
        Console.WriteLine("Edad invalida, intende de nuevo");
    }

} while ((edadUsuario < 1) || (edadUsuario > 100));
*/




int numeroUsuario;
int eleccion;
do
{
    Console.WriteLine("Ingrese el número de la tabla de multiplicar que deseé");
    numeroUsuario = Convert.ToInt32(Console.ReadLine());


    for (int i = 1; i < 11; i++)
    {
        Console.WriteLine(numeroUsuario +" x "+ i +" = "+ numeroUsuario*i);
    }

    Console.WriteLine("Desea conocer la tabla de otro número, presione 1 si desea continuar o presione cualquier otro número si desea finzalizr");
    eleccion = Convert.ToInt32(Console.ReadLine());

} while(eleccion == 1);
